	function showDetails(number) {
	    var numberType = number.getAttribute("data-num");
		$(".submit").click(function(){
			p1=numberType
			console.log(p1)
			var mobile=$(".prependedInput").val();
		})
	}
